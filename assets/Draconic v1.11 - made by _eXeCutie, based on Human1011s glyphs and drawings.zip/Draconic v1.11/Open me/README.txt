Copyright (c) 

This is a custom font made for Human1011's language, Draconic, used under CC BY-NC-SA 4.0.
This font is not for commercial use and must be shared under the same license.

____________________________________________________________________________________________________________________



If you've downloaded this file, i will assume that you are researching Draconic, and for that i recommend joining Human1011's Discord server:
https://discord.gg/By5MxEy6MT
https://linktr.ee/human1011
https://linktr.ee/_executie